import fs from 'fs/promises';
import { createWriteStream, WriteStream } from 'fs';
import path from 'path';
import { createLogger } from '../../logging/logger.js';
import { getTimeTakenSincePoint } from '../../utils/time.js';
import { getDataFolder, makeRequest } from '../../utils/index.js';
import { config as appConfig } from '../../config/index.js';
import { BaseDataset } from '../base/dataset.js';

const logger = createLogger('seadex');

export interface SeaDexTorrent {
  /** Empty string when SeaDex redacts the hash. */
  infoHash: string;
  releaseGroup?: string;
  tracker?: string;
  dualAudio?: boolean;
  created?: string;
  isBest: boolean;
  size: number;
}

interface SeaDexData {
  torrentsByAnilistId: Record<string, SeaDexTorrent[]>;
  lastUpdated: number;
}

/** Sum `length` over a raw SeaDex `files` array, tolerating malformed rows. */
function sumFileLengths(files: unknown): number {
  if (!Array.isArray(files)) return 0;
  let total = 0;
  for (const f of files) {
    const len = (f as { length?: unknown })?.length;
    if (typeof len === 'number' && Number.isFinite(len)) total += len;
  }
  return total;
}

// ensure size is present and files is not.
function normaliseSeaDexData(raw: any): SeaDexData {
  const src = (raw?.torrentsByAnilistId ?? {}) as Record<string, any[]>;
  const torrentsByAnilistId: Record<string, SeaDexTorrent[]> = {};
  for (const [anilistId, torrents] of Object.entries(src)) {
    if (!Array.isArray(torrents)) continue;
    torrentsByAnilistId[anilistId] = torrents.map((t) => ({
      infoHash: typeof t?.infoHash === 'string' ? t.infoHash : '',
      releaseGroup: t?.releaseGroup,
      tracker: t?.tracker,
      dualAudio: t?.dualAudio,
      created: t?.created,
      isBest: t?.isBest === true,
      size: typeof t?.size === 'number' ? t.size : sumFileLengths(t?.files),
    }));
  }
  return {
    torrentsByAnilistId,
    lastUpdated: typeof raw?.lastUpdated === 'number' ? raw.lastUpdated : 0,
  };
}

export class SeaDexDataset extends BaseDataset {
  private static instance: SeaDexDataset;
  private data: SeaDexData = {
    torrentsByAnilistId: {},
    lastUpdated: 0,
  };
  protected logger = logger;

  private constructor() {
    super({
      dataPath: path.join(getDataFolder(), 'seadex', 'trs.json'),
      refreshIntervalSeconds: appConfig.builtins.seadex.datasetRefreshInterval,
      logger,
      taskId: 'seadex-dataset-refresh',
      taskLabel: 'SeaDex dataset refresh',
      taskDescription:
        'Re-download the SeaDex torrent set used by the SeaDex built-in addon.',
    });
  }

  public static getInstance(): SeaDexDataset {
    if (!SeaDexDataset.instance) {
      SeaDexDataset.instance = new SeaDexDataset();
    }
    return SeaDexDataset.instance;
  }

  protected async reloadDataFromFile(): Promise<void> {
    try {
      const fileContent = await fs.readFile(this.DATA_PATH, 'utf-8');
      this.data = normaliseSeaDexData(JSON.parse(fileContent));
      logger.info(
        `Loaded SeaDex dataset with ${
          Object.keys(this.data.torrentsByAnilistId).length
        } entries`
      );
    } catch (error) {
      logger.error('Failed to reload SeaDex dataset from file:', error);
    }
  }

  protected async performSync(): Promise<void> {
    const startTime = Date.now();
    const tempPath = `${this.DATA_PATH}.tmp`;
    let writeStream: WriteStream | null = null;

    try {
      // Ensure temp directory exists
      await fs.mkdir(path.dirname(tempPath), { recursive: true });

      writeStream = createWriteStream(tempPath, { flags: 'w' });
      writeStream.on('error', (err: Error) => {
        logger.error('WriteStream error:', err);
      });

      writeStream.write('{"torrentsByAnilistId":{');

      let page = 1;
      let totalPages = 1;
      let totalEntries = 0;
      let firstEntry = true;
      do {
        const response = await makeRequest(
          `https://releases.moe/api/collections/entries/records?expand=trs&perPage=500&page=${page}`,
          {
            method: 'GET',
            timeout: 15000,
            headers: {
              'User-Agent': appConfig.http.defaultUserAgent,
              Accept: 'application/json',
            },
          }
        );

        if (!response.ok) {
          throw new Error(
            `Failed to fetch page ${page}: ${response.status} ${response.statusText}`
          );
        }

        const text = await response.text();
        let json: any;
        try {
          json = JSON.parse(text);
        } catch (e) {
          throw new Error(`Failed to parse JSON for page ${page}`);
        }

        if (
          typeof json.page !== 'number' ||
          typeof json.totalPages !== 'number'
        ) {
          throw new Error('Invalid SeaDex API response format');
        }

        totalPages = json.totalPages;

        // Process items and stream to file
        if (Array.isArray(json.items)) {
          for (const item of json.items) {
            if (!item?.expand?.trs || !Array.isArray(item.expand.trs)) continue;
            if (typeof item.alID !== 'number') continue;

            const torrents: SeaDexTorrent[] = [];
            for (const tr of item.expand.trs) {
              if (typeof tr.isBest !== 'boolean') {
                continue;
              }

              const rawHash =
                typeof tr.infoHash === 'string' ? tr.infoHash : '';
              const redacted = rawHash === '' || rawHash.includes('<redacted>');
              const releaseGroup =
                typeof tr.releaseGroup === 'string' && tr.releaseGroup !== ''
                  ? tr.releaseGroup
                  : undefined;

              if (redacted && !releaseGroup) {
                continue;
              }

              torrents.push({
                infoHash: redacted ? '' : rawHash.toLowerCase(),
                releaseGroup,
                isBest: tr.isBest,
                size: sumFileLengths(tr.files),
                tracker: tr.tracker,
                dualAudio: tr.dualAudio,
                created: tr.created,
              });
            }

            if (torrents.length > 0) {
              const alIDStr = item.alID.toString();

              if (!firstEntry) {
                writeStream.write(',');
              }
              writeStream.write(`"${alIDStr}":${JSON.stringify(torrents)}`);
              firstEntry = false;
              totalEntries++;
            }
          }
        }

        logger.debug(`Synced SeaDex page ${page}/${totalPages}`);
        page++;

        await new Promise((resolve) => setTimeout(resolve, 500));
      } while (page <= totalPages);

      writeStream.write(`},"lastUpdated":${Date.now()}}`);
      writeStream.end();

      await new Promise<void>((resolve, reject) => {
        if (!writeStream) {
          return reject(new Error('WriteStream is null'));
        }
        writeStream.on('finish', () => resolve());
        writeStream.on('error', reject);
      });

      await fs.rename(tempPath, this.DATA_PATH);

      logger.info(
        `SeaDex sync completed in ${getTimeTakenSincePoint(startTime)}. Total entries: ${totalEntries}`
      );
    } catch (error) {
      try {
        if (writeStream) {
          writeStream.destroy();
        }
        await fs.unlink(tempPath);
      } catch {}
      throw error;
    }
  }

  public getTorrents(anilistId: number): SeaDexTorrent[] {
    return this.data.torrentsByAnilistId[anilistId.toString()] || [];
  }
}
