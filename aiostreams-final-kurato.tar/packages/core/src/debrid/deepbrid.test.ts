import assert from 'node:assert/strict';
import test from 'node:test';
import {
  DeepbridService,
  selectDeepbridUploadFile,
  type DeepbridOfficialApi,
} from './deepbrid.js';
import {
  DeepbridApiError,
  parseDeepbridAddResponse,
} from '../builtins/deepbrid-usenet/client.js';
import { decodeDeepbridPlaybackToken } from '../builtins/deepbrid-usenet/playback.js';
import { DebridError } from './base.js';

function proxiedDeepbridTarget(url: string | undefined): string | undefined {
  if (!url) return undefined;
  const marker = '/builtins/deepbrid-usenet/play/';
  const remainder = new URL(url).pathname.split(marker)[1];
  assert.ok(remainder, 'expected an authenticated Deepbrid playback URL');
  return decodeDeepbridPlaybackToken(remainder.split('/')[0]).url;
}

test('parses the direct files returned by Deepbrid NZB add', () => {
  const result = parseDeepbridAddResponse({
    data: {
      upload_id: 42,
      title: 'Tower Prep S01',
      files: [
        {
          filename: 'Tower.Prep.S01E09.720p.mkv',
          download_url: 'https://usenet.myfast.link/e9',
          filesize: 2_000,
        },
      ],
    },
  });
  assert.equal(result.id, '42');
  assert.equal(result.title, 'Tower Prep S01');
  assert.deepEqual(result.files, [
    {
      name: 'Tower.Prep.S01E09.720p.mkv',
      link: 'https://usenet.myfast.link/e9',
      size: 2_000,
      sizeHuman: '',
    },
  ]);
});

test('Deepbrid upload selection prefers the requested video over archives', () => {
  const selected = selectDeepbridUploadFile(
    [
      {
        name: 'release.rar',
        link: 'https://cdn.deepbrid.com/release.rar',
        size: 2_000,
      },
      {
        name: 'release.nfo',
        link: 'https://cdn.deepbrid.com/release.nfo',
        size: 500,
      },
      {
        name: 'Show.S01E01.720p.mkv',
        link: 'https://cdn.deepbrid.com/episode.mkv',
        size: 700,
      },
    ],
    'Show.S01E01.720p.mkv'
  );
  assert.equal(selected?.name, 'Show.S01E01.720p.mkv');
});

test('Deepbrid upload selection falls back to the largest playable video', () => {
  const selected = selectDeepbridUploadFile(
    [
      {
        name: 'readme.txt',
        link: 'https://cdn.deepbrid.com/readme.txt',
        size: 1,
      },
      {
        name: 'small.mp4',
        link: 'https://cdn.deepbrid.com/small.mp4',
        size: 10,
      },
      {
        name: 'large.mkv',
        link: 'https://cdn.deepbrid.com/large.mkv',
        size: 100,
      },
    ],
    'missing.mkv'
  );
  assert.equal(selected?.name, 'large.mkv');
});

test('Deepbrid upload selection returns no file when an upload has no video', () => {
  assert.equal(
    selectDeepbridUploadFile(
      [{ name: 'release.rar', link: 'https://cdn.deepbrid.com/release.rar' }],
      'release.mkv'
    ),
    undefined
  );
});

test('Deepbrid upload selection chooses the requested member of a season pack', () => {
  const selected = selectDeepbridUploadFile(
    [
      {
        name: 'Tower.Prep.S01E01.720p.mkv',
        link: 'https://usenet.myfast.link/e1',
        size: 1,
      },
      {
        name: 'Tower.Prep.S01E09.720p.mkv',
        link: 'https://usenet.myfast.link/e9',
        size: 2,
      },
    ],
    'Tower Prep S01',
    { season: 1, episode: 9 }
  );
  assert.equal(selected?.name, 'Tower.Prep.S01E09.720p.mkv');
});

test('Deepbrid upload selection never substitutes the wrong pack episode', () => {
  const selected = selectDeepbridUploadFile(
    [
      {
        name: 'Tower.Prep.S01E01.720p.mkv',
        link: 'https://usenet.myfast.link/e1',
      },
      {
        name: 'Tower.Prep.S01E02.720p.mkv',
        link: 'https://usenet.myfast.link/e2',
      },
    ],
    'Tower Prep S01',
    { season: 1, episode: 9 }
  );
  assert.equal(selected, undefined);
});

function fakeDeepbridApi(): DeepbridOfficialApi {
  return {
    async getUser() {
      return { id: 'account' };
    },
    async listUploads() {
      return [
        {
          id: 'upload-1',
          title: 'Tower Prep S01',
          source: 'url',
          sourceUrl: 'https://indexer.example/tower-prep.nzb',
          addedAt: '2026-08-20T00:00:00Z',
        },
      ];
    },
    async addNzbUrl() {
      return { id: 'upload-1', title: 'Tower Prep S01', files: [] };
    },
    async getUploadInfo() {
      return {
        id: 'upload-1',
        title: 'Tower Prep S01',
        files: [
          {
            name: 'Tower.Prep.S01E01.720p.mkv',
            link: 'https://usenet.myfast.link/e1',
            size: 1_000_000_000,
            sizeHuman: '1 GB',
          },
          {
            name: 'Tower.Prep.S01E09.720p.mkv',
            link: 'https://usenet.myfast.link/e9',
            size: 2_000_000_000,
            sizeHuman: '2 GB',
          },
        ],
      };
    },
  };
}

test('Deepbrid service recognizes and verifies an already-owned external NZB', async () => {
  let probeCalls = 0;
  const service = new DeepbridService(
    { token: 'owned-check-test-token' },
    fakeDeepbridApi(),
    async () => {
      probeCalls++;
      return true;
    }
  );
  const [result] = await service.checkNzbs([
    {
      name: 'Tower Prep S01',
      hash: 'external-hash',
      nzb: 'https://indexer.example/tower-prep.nzb',
    },
  ]);
  assert.equal(result.id, 'upload-1');
  assert.equal(result.status, 'cached');
  assert.equal(result.library, true);
  assert.equal(result.hash, 'external-hash');
  assert.equal(probeCalls, 2);
});

test('Deepbrid without pre-cache omits bad owned uploads but keeps uncached NZBs on demand', async () => {
  const client = fakeDeepbridApi();
  client.listUploads = async () => [
    {
      id: 'bad-existing-upload',
      title: 'Bad existing upload',
      source: 'url',
      sourceUrl: 'https://indexer.example/bad-existing.nzb',
    },
  ];
  client.getUploadInfo = async () => ({
    id: 'bad-existing-upload',
    title: 'Bad existing upload',
    files: [
      {
        name: 'Bad.Existing.Upload.1080p.mkv',
        link: 'https://usenet.myfast.link/generated-error',
        size: 4_000_000_000,
        sizeHuman: '4 GB',
      },
    ],
  });
  const service = new DeepbridService(
    { token: 'owned-negative-test-token' },
    client,
    async () => false
  );

  const results = await service.checkNzbs([
    {
      name: 'Bad existing upload',
      hash: 'bad-existing-hash',
      nzb: 'https://indexer.example/bad-existing.nzb',
    },
    {
      name: 'Uncached release',
      hash: 'uncached-on-demand-hash',
      nzb: 'https://indexer.example/uncached-on-demand.nzb',
    },
  ]);

  assert.deepEqual(
    results.map((result) => ({ hash: result.hash, status: result.status })),
    [{ hash: 'uncached-on-demand-hash', status: 'queued' }]
  );
});

test('Deepbrid torrent library is read-only and matches only account torrents', async () => {
  const client = fakeDeepbridApi();
  client.listTorrents = async () => [
    {
      id: 'torrent-1',
      hash: 'ABC123',
      title: 'Manually added movie',
      status: 'completed',
      progress: 100,
      size: 12_000_000_000,
      files: [
        {
          name: 'Manually.Added.Movie.1080p.mkv',
          link: 'https://premium-dl.deepbrid.com/movie',
          size: 12_000_000_000,
          sizeHuman: '12 GB',
        },
      ],
    },
  ];
  const service = new DeepbridService({ token: 'torrent-library' }, client);
  const [match] = await service.checkMagnets(['abc123', 'not-owned']);

  assert.equal(match.id, 'torrent-1');
  assert.equal(match.library, true);
  assert.equal(match.status, 'cached');
  await assert.rejects(() => service.addMagnet('magnet:?xt=urn:btih:not-owned'));
});

test('Deepbrid library catalog items can be opened through authenticated torrent info', async () => {
  const client = fakeDeepbridApi();
  client.getTorrentInfo = async (id) => ({
    id,
    title: 'Titanic.1997.2160p.UHD.Blu-ray.Remux.HEVC',
    status: 'completed',
    progress: 100,
    files: [
      {
        name: 'Titanic.1997.2160p.UHD.Blu-ray.Remux.HEVC',
        link: 'https://www.deepbrid.com/mytorrents?torrent=1&file=abc',
        size: 20_000_000_000,
        sizeHuman: '20 GB',
      },
    ],
  });

  const service = new DeepbridService({ token: 'torrent-library-open' }, client);
  const result = await service.getMagnet('torrent-1');

  assert.equal(result.id, 'torrent-1');
  assert.equal(result.library, true);
  assert.equal(result.files?.length, 1);
});

test('Deepbrid library playback resolves the exact requested multi-file link', async () => {
  const client = fakeDeepbridApi();
  client.getTorrentInfo = async (id) => ({
    id,
    title: 'DTS-MusicDemo_BDRemux',
    status: 'completed',
    progress: 100,
    files: [
      {
        name: 'DTS-MusicDemo_BDRemux',
        link: 'https://www.deepbrid.com/mytorrents?torrent=1&file=first',
        size: 2_000_000_000,
        sizeHuman: '2 GB',
      },
      {
        name: 'DTS-MusicDemo_BDRemux',
        link: 'https://www.deepbrid.com/mytorrents?torrent=1&file=second',
        size: 3_000_000_000,
        sizeHuman: '3 GB',
      },
    ],
  });

  const service = new DeepbridService({ token: 'multi-file-playback' }, client);
  const link = await service.resolve(
    {
      type: 'torrent',
      hash: 'unused',
      serviceItemId: 'torrent-1',
      fileIndex: 1,
      cacheAndPlay: false,
      autoRemoveDownloads: false,
      sources: [],
    },
    'DTS-MusicDemo_BDRemux',
    false
  );

  assert.equal(
    proxiedDeepbridTarget(link),
    'https://www.deepbrid.com/mytorrents?torrent=1&file=second'
  );
});

test('Deepbrid pre-cache mode emits only verified external NZBs', async () => {
  const client = fakeDeepbridApi();
  let receivedSignal = false;
  client.listUploads = async () => [];
  client.addNzbUrl = async (_url, options) => {
    receivedSignal = options?.signal instanceof AbortSignal;
    return {
      id: 'pre-cached-upload',
      title: 'External release',
      files: [],
    };
  };
  client.getUploadInfo = async () => ({
    id: 'pre-cached-upload',
    title: 'External release',
    files: [
      {
        name: 'External.Release.S01E04.1080p.mkv',
        link: 'https://usenet.myfast.link/pre-cached',
        size: 1_000_000_000,
        sizeHuman: '1 GB',
      },
    ],
  });

  const service = new DeepbridService(
    { token: 'pre-cache', preCache: true, preCacheLimit: 1 },
    client,
    async () => true
  );
  const [result] = await service.checkNzbs([
    {
      name: 'External release',
      hash: 'external-pre-cache-hash',
      nzb: 'https://indexer.example/external-pre-cache.nzb',
    },
  ]);

  assert.equal(result.id, 'pre-cached-upload');
  assert.equal(result.status, 'cached');
  assert.equal(result.library, true);
  assert.equal(result.files?.[0]?.name, 'External.Release.S01E04.1080p.mkv');
  assert.equal(receivedSignal, true);
});

test('Deepbrid pre-cache omits failed candidates while retaining verified ones', async () => {
  const client = fakeDeepbridApi();
  client.listUploads = async () => [];
  client.addNzbUrl = async (url) => {
    if (url.includes('rate-limited')) {
      throw new DeepbridApiError('NZB fetch failed', 429);
    }
    return { id: 'verified-upload', title: 'Verified release', files: [] };
  };
  client.getUploadInfo = async () => ({
    id: 'verified-upload',
    title: 'Verified release',
    files: [
      {
        name: 'Verified.Release.S01E04.1080p.mkv',
        link: 'https://usenet.myfast.link/verified',
        size: 1_000_000_000,
        sizeHuman: '1 GB',
      },
    ],
  });

  const service = new DeepbridService(
    { token: 'pre-cache-partial', preCache: true, preCacheLimit: 2 },
    client,
    async () => true
  );
  const results = await service.checkNzbs([
    {
      name: 'Verified release',
      hash: 'verified-hash',
      nzb: 'https://indexer.example/verified.nzb',
    },
    {
      name: 'Rate limited release',
      hash: 'rate-limited-hash',
      nzb: 'https://indexer.example/rate-limited.nzb',
    },
  ]);

  assert.deepEqual(results.map((result) => result.status), ['cached']);
  assert.equal(results[0]?.library, true);
  assert.equal(results.length, 1);
});

test('Deepbrid pre-cache verifies owned uploads and omits generated error videos', async () => {
  const client = fakeDeepbridApi();
  let probeCalls = 0;
  client.listUploads = async () => [
    {
      id: 'bad-owned-upload',
      title: 'The Hawk S01E06',
      source: 'url',
      sourceUrl: 'https://indexer.example/hawk.nzb',
    },
  ];
  client.getUploadInfo = async () => ({
    id: 'bad-owned-upload',
    title: 'The Hawk S01E06',
    files: [
      {
        name: 'The.Hawk.S01E06.1080p.mkv',
        link: 'https://usenet.myfast.link/generated-error',
        // Deepbrid metadata can advertise the release size while the actual
        // ranged link serves a tiny generated error video.
        size: 5_476_083_302,
        sizeHuman: '5.1 GB',
      },
    ],
  });

  const service = new DeepbridService(
    { token: 'verify-bad-owned', preCache: true, preCacheLimit: 1 },
    client,
    async () => {
      probeCalls++;
      return false;
    }
  );
  const results = await service.checkNzbs([
    {
      name: 'The Hawk S01E06',
      hash: 'hawk-owned-hash',
      nzb: 'https://indexer.example/hawk.nzb',
    },
  ]);

  assert.deepEqual(results, []);
  assert.equal(probeCalls, 1);
});

test('Deepbrid playback reuses the scrape-verified link instead of a refreshed error video', async () => {
  const scrapeClient = fakeDeepbridApi();
  scrapeClient.listUploads = async () => [
    {
      id: 'stable-upload-id',
      title: 'The Hawk S01E06',
      source: 'url',
      sourceUrl: 'https://indexer.example/hawk-stable.nzb',
    },
  ];
  scrapeClient.getUploadInfo = async () => ({
    id: 'stable-upload-id',
    title: 'The Hawk S01E06',
    files: [
      {
        name: 'The.Hawk.S01E06.2160p.mkv',
        link: 'https://usenet.myfast.link/verified-media',
        size: 5_476_083_302,
        sizeHuman: '5.1 GB',
      },
    ],
  });
  const scrapeService = new DeepbridService(
    { token: 'stable-playback-cache', preCache: true, preCacheLimit: 1 },
    scrapeClient,
    async (file) => file.link.endsWith('/verified-media')
  );
  const [cached] = await scrapeService.checkNzbs([
    {
      name: 'The Hawk S01E06',
      hash: 'stable-hawk-hash',
      nzb: 'https://indexer.example/hawk-stable.nzb',
    },
  ]);
  assert.equal(cached.id, 'stable-upload-id');

  let refreshedInfoCalls = 0;
  const playbackClient = fakeDeepbridApi();
  playbackClient.getUploadInfo = async () => {
    refreshedInfoCalls++;
    return {
      id: 'stable-upload-id',
      title: 'The Hawk S01E06',
      files: [
        {
          name: 'The.Hawk.S01E06.2160p.mkv',
          link: 'https://usenet.myfast.link/generated-error',
          size: 5_476_083_302,
          sizeHuman: '5.1 GB',
        },
      ],
    };
  };
  const playbackService = new DeepbridService(
    { token: 'stable-playback-cache' },
    playbackClient,
    async () => false
  );
  const url = await playbackService.resolve(
    {
      type: 'usenet',
      hash: 'stable-hawk-hash',
      nzb: 'https://indexer.example/hawk-stable.nzb',
      serviceItemId: 'stable-upload-id',
      metadata: { titles: ['The Hawk'], season: 1, episode: 6, airDates: [] },
    },
    'The.Hawk.S01E06.2160p.mkv',
    true
  );

  assert.equal(
    proxiedDeepbridTarget(url),
    'https://usenet.myfast.link/verified-media'
  );
  assert.equal(refreshedInfoCalls, 0);
});

test('Deepbrid service resolves the requested episode from an owned upload', async () => {
  const service = new DeepbridService(
    { token: 'owned-upload-test-token' },
    fakeDeepbridApi(),
    async () => true
  );
  const url = await service.resolve(
    {
      type: 'usenet',
      hash: 'external-hash',
      nzb: 'https://indexer.example/tower-prep.nzb',
      serviceItemId: 'upload-1',
      metadata: { titles: ['Tower Prep'], season: 1, episode: 9, airDates: [] },
    },
    'Tower Prep S01',
    true
  );
  assert.equal(proxiedDeepbridTarget(url), 'https://usenet.myfast.link/e9');
});

test('Deepbrid service uses playable files returned directly by NZB add', async () => {
  let infoCalls = 0;
  let addCalls = 0;
  const client = fakeDeepbridApi();
  client.listUploads = async () => [];
  client.addNzbUrl = async () => {
    addCalls++;
    return {
      id: 'non-library-job-id',
      title: 'Tower Prep S01',
      files: [
        {
          name: 'Tower.Prep.S01E01.720p.mkv',
          link: `https://usenet.myfast.link/e1-${addCalls}`,
          size: 1_000_000_000,
          sizeHuman: '1 GB',
        },
        {
          name: 'Tower.Prep.S01E09.720p.mkv',
          link: `https://usenet.myfast.link/e9-${addCalls}`,
          size: 2_000_000_000,
          sizeHuman: '2 GB',
        },
      ],
    };
  };
  client.getUploadInfo = async () => {
    infoCalls++;
    throw new Error('must not poll when add already returned files');
  };

  const service = new DeepbridService(
    { token: 'direct-add-test-token' },
    client
  );
  const url = await service.resolve(
    {
      type: 'usenet',
      hash: 'external-hash-direct',
      nzb: 'https://indexer.example/tower-prep-direct.nzb',
      metadata: { titles: ['Tower Prep'], season: 1, episode: 9, airDates: [] },
    },
    'Tower Prep S01',
    true
  );
  assert.equal(
    proxiedDeepbridTarget(url),
    'https://usenet.myfast.link/e9-1'
  );
  assert.equal(addCalls, 1);
  assert.equal(infoCalls, 0);
});

test('Deepbrid service recovers the canonical upload id after a missing-id response', async () => {
  let listCalls = 0;
  const client = fakeDeepbridApi();
  client.listUploads = async () => {
    listCalls++;
    return [
      {
        id: 'canonical-upload-id',
        title: 'Tower Prep S01',
        source: 'url',
        sourceUrl: 'https://indexer.example/tower-prep-recover.nzb',
      },
    ];
  };
  client.addNzbUrl = async () => ({
    id: 'non-library-job-id',
    title: 'Tower Prep S01',
    files: [],
  });
  client.getUploadInfo = async (id) => {
    if (id !== 'canonical-upload-id') {
      throw new DeepbridApiError('Missing id', 200, 'api_1');
    }
    return {
      id,
      title: 'Tower Prep S01',
      files: [
        {
          name: 'Tower.Prep.S01E09.720p.mkv',
          link: 'https://usenet.myfast.link/e9',
          size: 2_000_000_000,
          sizeHuman: '2 GB',
        },
      ],
    };
  };

  const service = new DeepbridService(
    { token: 'recover-id-test-token' },
    client,
    async () => true
  );
  const url = await service.resolve(
    {
      type: 'usenet',
      hash: 'external-hash-recover',
      nzb: 'https://indexer.example/tower-prep-recover.nzb',
      metadata: { titles: ['Tower Prep'], season: 1, episode: 9, airDates: [] },
    },
    'Tower Prep S01',
    true
  );
  assert.equal(proxiedDeepbridTarget(url), 'https://usenet.myfast.link/e9');
  assert.equal(listCalls, 1);
});

test('Deepbrid service rejects generated error videos as retryable playback failures', async () => {
  const client = fakeDeepbridApi();
  client.listUploads = async () => [];
  client.addNzbUrl = async () => ({
    id: 'job-id',
    title: 'Broken release',
    files: [
      {
        name: 'Broken.Release.1080p.mkv',
        link: 'https://usenet.myfast.link/error-video',
        size: 21_982,
        sizeHuman: '21 KB',
      },
    ],
  });
  const service = new DeepbridService({ token: 'error-video' }, client);

  await assert.rejects(
    service.resolve(
      {
        type: 'usenet',
        hash: 'broken-hash',
        nzb: 'https://indexer.example/broken.nzb',
      },
      'Broken.Release.1080p.mkv',
      true
    ),
    (error: unknown) =>
      error instanceof DebridError &&
      error.statusCode === 502 &&
      error.code === 'BAD_GATEWAY'
  );
});
