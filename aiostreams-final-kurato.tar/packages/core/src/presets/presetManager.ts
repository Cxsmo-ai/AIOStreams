import { PresetMetadata, PresetMinimalMetadata } from '../db/index.js';
import { CometPreset } from './comet.js';
import { MeteorPreset } from './meteor.js';
import { CustomPreset } from './custom.js';
import { MediaFusionPreset } from './mediafusion.js';
import { StremthruStorePreset } from './stremthruStore.js';
import { TorrentioPreset } from './torrentio.js';
import { TorrentClawPreset } from './torrentclaw.js';
import { TorboxAddonPreset } from './torbox.js';
import { EasynewsPreset } from './easynews.js';
import { EasynewsPlusPreset } from './easynewsPlus.js';
import { EasynewsPlusPlusPreset } from './easynewsPlusPlus.js';
import { StremthruTorzPreset } from './stremthruTorz.js';
import { DebridioPreset } from './debridioScraper.js';
import { AIOStreamsPreset } from './aiostreams.js';
import { OpenSubtitlesPreset } from './opensubtitles.js';
import { PeerflixPreset } from './peerflix.js';
import { DMMCastPreset } from './dmmCast.js';
import { MarvelPreset } from './marvel.js';
import { JackettioPreset } from './jackettio.js';
import { OrionPreset } from './orion.js';
import { StreamFusionPreset } from './streamfusion.js';
import { AnimeKitsuPreset } from './animeKitsu.js';
import { NuvioStreamsPreset } from './nuviostreams.js';
import { RpdbCatalogsPreset } from './rpdbCatalogs.js';
import { TmdbCollectionsPreset } from './tmdbCollections.js';
import { DebridioWatchtowerPreset } from './debridioWatchtower.js';
import { DebridioTmdbPreset } from './debridioTmdb.js';
import { StarWarsUniversePreset } from './starWarsUniverse.js';
import { DebridioTvdbPreset } from './debridioTvdb.js';
import { DcUniversePreset } from './dcUniverse.js';
import { DebridioTvPreset } from './debridioTv.js';
import { DebridioIC4APreset } from './debridioIc4a.js';
import { TorrentCatalogsPreset } from './torrentCatalogs.js';
import { StreamingCatalogsPreset } from './streamingCatalogs.js';
import { AnimeCatalogsPreset } from './animeCatalogs.js';
import { DoctorWhoUniversePreset } from './doctorWhoUniverse.js';
import { WebStreamrPreset } from './webstreamr.js';
import { TMDBAddonPreset } from './tmdb.js';
import { TorrentsDbPreset } from './torrentsDb.js';
import { USATVPreset } from './usaTv.js';
import { ArgentinaTVPreset } from './argentinaTv.js';
import { OpenSubtitlesV3PlusPreset } from './opensubtitles-v3-plus.js';
import { DeepbridOpenSubtitlesPreset } from './deepbridOpenSubtitles.js';
import { SubSourcePreset } from './subsource.js';
import { SubDLPreset } from './subdl.js';
import { AISearchPreset } from './aiSearch.js';
import { FKStreamPreset } from './fkstream.js';
import { FlixStreamsPreset } from './flixStreams.js';
import { AIOSubtitlePreset } from './aiosubtitle.js';
import { SubHeroPreset } from './subhero.js';
import { YastreamPreset } from './yastream.js';
import { StreamAsiaPreset } from './streamasia.js';
import { MoreLikeThisPreset } from './moreLikeThis.js';
import { GDriveAPI } from '../builtins/gdrive/index.js';
import { GDrivePreset } from './gdrive.js';
import { ContentDeepDivePreset } from './contentDeepDive.js';
import { AICompanionPreset } from './aiCompanion.js';
import { GoogleOAuth } from '../builtins/gdrive/api.js';
import { TorBoxSearchPreset } from './torboxSearch.js';
import { TorznabPreset } from './torznab.js';
import { AStreamPreset } from './aStream.js';
import { ZileanPreset } from './zilean.js';
import { AnimeToshoPreset } from './animetosho.js';
import { NewznabPreset } from './newznab.js';
import { UnarrIndexerPreset } from './unarrIndexer.js';
import { NewshostingIndexerPreset } from './newshostingIndexer.js';
import { DeepbridUsenetPreset } from './deepbridUsenet.js';
import { ProwlarrPreset } from './prowlarr.js';
import { JackettPreset } from './jackett.js';
import { NZBHydraPreset } from './nzbhydra.js';
import { KnabenPreset } from './knaben.js';
import { LibraryPreset } from './library.js';
import { EztvPreset } from './eztv.js';
import { BitmagnetPreset } from './bitmagnet.js';
import { BrazucaTorrentsPreset } from './brazucaTorrents.js';
import { SootioPreset } from './sootio.js';
import { TorrentGalaxyPreset } from './torrentGalaxy.js';
import { UsenetStreamerPreset } from './usenetStreamer.js';
import { NekoBtPreset } from './nekoBt.js';
import { EasynewsSearchPreset } from './easynewsSearch.js';
import { SeaDexPreset } from './seadex.js';
import { StreamNZBPreset } from './streamnzb.js';
import { DavexPreset } from './davex.js';
import { HdHubPreset } from './hdhub.js';
import { KuratoPreset } from './kurato.js';
import { BaguettioPreset } from './baguettio.js';
import { Preset } from './index.js';

let PRESET_LIST: string[] = [
  'custom',
  'torznab',
  'newznab',
  'unarr-indexer',
  'newshosting-indexer',
  'deepbrid-usenet',
  'aiostreams',
  'torrentio',
  'torrentclaw',
  'comet',
  'meteor',
  'mediafusion',
  'stremthruTorz',
  'stremthruStore',
  'sootio',
  'zilean',
  'knaben',
  'library',
  'eztv',
  'torrent-galaxy',
  'bitmagnet',
  'seadex',
  'animetosho',
  'neko-bt',
  'prowlarr',
  'jackett',
  'nzbhydra',
  'stremio-gdrive',
  'jackettio',
  'peerflix',
  'orion',
  'torrents-db',
  'streamfusion',
  'baguettio',
  'fkstream',
  'debridio',
  'torbox',
  'torbox-search',
  'easynews-search',
  'easynews',
  'easynewsPlus',
  'easynewsPlusPlus',
  'usenet-streamer',
  'streamnzb',
  'davex',
  'dmm-cast',
  'nuvio-streams',
  'webstreamr',
  'hdhub',
  'flix-streams',
  'astream',
  'brazuca-torrents',
  'yastream',
  'streamasia',
  'usa-tv',
  'argentina-tv',
  'debridio-tv',
  'debridio-watchtower',
  'tmdb-addon',
  'debridio-tmdb',
  'debridio-tvdb',
  'debridio-ic4a',
  'streaming-catalogs',
  'anime-catalogs',
  'torrent-catalogs',
  'rpdb-catalogs',
  'tmdb-collections',
  'anime-kitsu',
  'marvel-universe',
  'star-wars-universe',
  'dc-universe',
  'doctor-who-universe',
  'opensubtitles',
  'deepbrid-opensubtitles',
  'opensubtitles-v3-plus',
  'subsource',
  'subdl',
  'subhero',
  'aiosubtitle',
  'ai-companion',
  'ai-search',
  'more-like-this',
  'content-deep-dive',
  'kurato',
].filter(Boolean);

export class PresetManager {
  static getPresetList(): PresetMinimalMetadata[] {
    return PRESET_LIST.map((presetId) => this.fromId(presetId).METADATA).map(
      (metadata: PresetMetadata) => ({
        ID: metadata.ID,
        NAME: metadata.NAME,
        LOGO: metadata.LOGO,
        DESCRIPTION: metadata.DESCRIPTION,
        SUPPORTED_RESOURCES: metadata.SUPPORTED_RESOURCES,
        SUPPORTED_STREAM_TYPES: metadata.SUPPORTED_STREAM_TYPES,
        SUPPORTED_SERVICES: metadata.SUPPORTED_SERVICES,
        OPTIONS: metadata.OPTIONS,
        BUILTIN: metadata.BUILTIN,
        DISABLED: metadata.DISABLED,
        CATEGORY: metadata.CATEGORY,
      })
    );
  }

  static fromId(id: string): typeof Preset {
    switch (id) {
      case 'torrentio':
        return TorrentioPreset;
      case 'torrentclaw':
        return TorrentClawPreset;
      case 'stremthruStore':
        return StremthruStorePreset;
      case 'stremthruTorz':
        return StremthruTorzPreset;
      case 'comet':
        return CometPreset;
      case 'meteor':
        return MeteorPreset;
      case 'mediafusion':
        return MediaFusionPreset;
      case 'custom':
        return CustomPreset;
      case 'torbox':
        return TorboxAddonPreset;
      case 'jackettio':
        return JackettioPreset;
      case 'easynews':
        return EasynewsPreset;
      case 'easynewsPlus':
        return EasynewsPlusPreset;
      case 'easynewsPlusPlus':
        return EasynewsPlusPlusPreset;
      case 'debridio':
        return DebridioPreset;
      case 'debridio-watchtower':
        return DebridioWatchtowerPreset;
      case 'debridio-tv':
        return DebridioTvPreset;
      case 'debridio-tmdb':
        return DebridioTmdbPreset;
      case 'debridio-tvdb':
        return DebridioTvdbPreset;
      case 'debridio-ic4a':
        return DebridioIC4APreset;
      case 'aiostreams':
        return AIOStreamsPreset;
      case 'opensubtitles':
        return OpenSubtitlesPreset;
      case 'deepbrid-opensubtitles':
        return DeepbridOpenSubtitlesPreset;
      case 'peerflix':
        return PeerflixPreset;
      case 'dmm-cast':
        return DMMCastPreset;
      case 'marvel-universe':
        return MarvelPreset;
      case 'orion':
        return OrionPreset;
      case 'streamfusion':
        return StreamFusionPreset;
      case 'fkstream':
        return FKStreamPreset;
      case 'flix-streams':
        return FlixStreamsPreset;
      case 'anime-kitsu':
        return AnimeKitsuPreset;
      case 'nuvio-streams':
        return NuvioStreamsPreset;
      case 'webstreamr':
        return WebStreamrPreset;
      case 'astream':
        return AStreamPreset;
      case 'streaming-catalogs':
        return StreamingCatalogsPreset;
      case 'anime-catalogs':
        return AnimeCatalogsPreset;
      case 'torrent-catalogs':
        return TorrentCatalogsPreset;
      case 'rpdb-catalogs':
        return RpdbCatalogsPreset;
      case 'tmdb-collections':
        return TmdbCollectionsPreset;
      case 'star-wars-universe':
        return StarWarsUniversePreset;
      case 'dc-universe':
        return DcUniversePreset;
      case 'doctor-who-universe':
        return DoctorWhoUniversePreset;
      case 'tmdb-addon':
        return TMDBAddonPreset;
      case 'torrents-db':
        return TorrentsDbPreset;
      case 'usa-tv':
        return USATVPreset;
      case 'argentina-tv':
        return ArgentinaTVPreset;
      case 'brazuca-torrents':
        return BrazucaTorrentsPreset;
      case 'opensubtitles-v3-plus':
        return OpenSubtitlesV3PlusPreset;
      case 'subsource':
        return SubSourcePreset;
      case 'subdl':
        return SubDLPreset;
      case 'ai-search':
        return AISearchPreset;
      case 'aiosubtitle':
        return AIOSubtitlePreset;
      case 'subhero':
        return SubHeroPreset;
      case 'yastream':
        return YastreamPreset;
      case 'streamasia':
        return StreamAsiaPreset;
      case 'more-like-this':
        return MoreLikeThisPreset;
      case 'content-deep-dive':
        return ContentDeepDivePreset;
      case 'kurato':
        return KuratoPreset;
      case 'ai-companion':
        return AICompanionPreset;
      case 'stremio-gdrive':
        return GDrivePreset;
      case 'torbox-search':
        return TorBoxSearchPreset;
      case 'torznab':
        return TorznabPreset;
      case 'newznab':
        return NewznabPreset;
      case 'unarr-indexer':
        return UnarrIndexerPreset;
      case 'newshosting-indexer':
        return NewshostingIndexerPreset;
      case 'deepbrid-usenet':
        return DeepbridUsenetPreset;
      case 'zilean':
        return ZileanPreset;
      case 'animetosho':
        return AnimeToshoPreset;
      case 'neko-bt':
        return NekoBtPreset;
      case 'prowlarr':
        return ProwlarrPreset;
      case 'jackett':
        return JackettPreset;
      case 'nzbhydra':
        return NZBHydraPreset;
      case 'knaben':
        return KnabenPreset;
      case 'library':
        return LibraryPreset;
      case 'eztv':
        return EztvPreset;
      case 'bitmagnet':
        return BitmagnetPreset;
      case 'seadex':
        return SeaDexPreset;
      case 'sootio':
        return SootioPreset;
      case 'torrent-galaxy':
        return TorrentGalaxyPreset;
      case 'usenet-streamer':
        return UsenetStreamerPreset;
      case 'easynews-search':
        return EasynewsSearchPreset;
      case 'streamnzb':
        return StreamNZBPreset;
      case 'davex':
        return DavexPreset;
      case 'hdhub':
        return HdHubPreset;
      case 'baguettio':
        return BaguettioPreset;
      default:
        throw new Error(`Preset ${id} not found`);
    }
  }
}
