import { Addon, ParsedStream, UserData } from '../db/schemas.js';
import {
  constants,
  createLogger,
  appConfig,
  getSimpleTextHash,
  encryptString,
  BuiltinServiceId,
  mergeParsedMediaInfos,
} from '../utils/index.js';
import {
  Torrent,
  BuiltinDebridServices,
  generatePlaybackUrl,
  metadataStore,
  fileInfoStore,
  TitleMetadata,
  FileInfo,
  NZB,
  NZBWithSelectedFile,
  hashNzbUrl,
  getTorboxRouteConfig,
} from '../debrid/index.js';
import { processTorrents, processNZBs } from '../builtins/utils/debrid.js';
import { StreamContext } from '../streams/context.js';
import { parseTorrentTitleCached } from '../parser/title.js';
import { PresetManager } from '../presets/presetManager.js';

const logger = createLogger('serviceWrapper');

export interface ServiceWrapResult {
  streams: ParsedStream[];
  errors: ServiceWrapError[];
  hasNewStreams: boolean;
  serviceTimings?: Record<string, ServiceWrapServiceTiming>;
}

export interface ServiceWrapServiceTiming {
  /** Time (ms) spent waiting for the debrid checkMagnets API response. */
  magnetCheckMs: number;
  /** Time (ms) spent on post-magnet-check processing (title validation, file selection, stream building). */
  processingMs: number;
  /** Total wall-clock time for this service (magnetCheckMs + processingMs). */
  totalMs: number;
  /** Number of cached results returned. */
  cachedCount: number;
  /** Number of uncached results returned. */
  uncachedCount: number;
  /** Number of torrents submitted to this service. */
  torrentsIn: number;
  /** Whether an error occurred during processing. */
  hasError?: boolean;
}

export interface ServiceWrapError {
  title: string;
  description: string;
}

/**
 * Resolve every external NZB through Deepbrid once, centrally, after all
 * indexer addons have been scraped. This is deliberately independent of the
 * per-addon service lists: a single global Deepbrid service selection now
 * covers altHUB, Newshosting, Easynews, Prowlarr, TorrentClaw, Unarr, and
 * other NZB-producing addons.
 */
export async function resolveGlobalDeepbridNzbs(
  streams: ParsedStream[],
  context: StreamContext,
  userData: UserData,
  addons: Addon[]
): Promise<ServiceWrapResult> {
  const deepbrid = buildDebridServices(userData).find(
    (service) => service.id === constants.DEEPBRID_SERVICE
  );
  if (!deepbrid) return { streams, errors: [], hasNewStreams: false };

  const candidates = streams.filter(
    (stream) =>
      !!stream.nzbUrl &&
      stream.service?.id !== constants.DEEPBRID_SERVICE &&
      stream.indexer !== constants.DEEPBRID_SERVICE &&
      stream.addon.identifier !== 'deepbrid-usenet'
  );
  if (candidates.length === 0)
    return { streams, errors: [], hasNewStreams: false };

  const byHash = new Map<string, ParsedStream[]>();
  const nzbsByHash = new Map<string, NZB>();
  for (const stream of candidates) {
    const nzbUrl = stream.nzbUrl!;
    const hash = hashNzbUrl(nzbUrl);
    const originals = byHash.get(hash) ?? [];
    originals.push(stream);
    byHash.set(hash, originals);
    if (!nzbsByHash.has(hash)) {
      nzbsByHash.set(hash, {
        type: 'usenet',
        hash,
        nzb: nzbUrl,
        title:
          stream.folderName ??
          stream.filename ??
          stream.originalName ??
          'External NZB',
        size: stream.folderSize ?? stream.size ?? 0,
        indexer: stream.indexer,
        confirmed: true,
      });
    }
  }

  const metadata = await buildMetadata(context);
  const processed = await processNZBs(
    [...nzbsByHash.values()],
    [deepbrid],
    context.id,
    metadata,
    userData.ip,
    userData.checkOwned ?? true
  );
  const errors: ServiceWrapError[] = processed.errors.map((error) => ({
    title: `[❌] Global Deepbrid Usenet`,
    description: error.error.message,
  }));
  if (processed.results.length === 0) {
    return { streams, errors, hasNewStreams: false };
  }

  const metadataToStore = metadata || { titles: [] };
  const metadataId = getSimpleTextHash(JSON.stringify(metadataToStore));
  await metadataStore().set(
    metadataId,
    metadataToStore,
    appConfig.builtins.debrid.playbackLinkValidity,
    true
  );
  const auth = encryptString(
    JSON.stringify({ id: deepbrid.id, credential: deepbrid.credential })
  ).data;
  if (!auth) return { streams, errors, hasNewStreams: false };

  const resolvedStreams: ParsedStream[] = [];
  for (const result of processed.results as NZBWithSelectedFile[]) {
    const originals = byHash.get(result.hash) ?? [];
    for (const original of originals) {
      const filename = result.file.name ?? result.title ?? 'video';
      const fileInfo: FileInfo = {
        type: 'usenet',
        nzb: result.nzb,
        title: result.title,
        hash: result.hash,
        index: result.file.index,
        indexer: result.indexer,
        cacheAndPlay:
          userData.cacheAndPlay?.enabled &&
          userData.cacheAndPlay.streamTypes?.includes('usenet'),
        autoRemoveDownloads: userData.autoRemoveDownloads,
        serviceItemId: result.serviceItemId,
      };
      const url = generatePlaybackUrl(auth, metadataId, fileInfo, filename);
      resolvedStreams.push({
        ...original,
        id: `${original.id}-deepbrid`,
        type: 'debrid',
        url,
        service: {
          id: constants.DEEPBRID_SERVICE,
          cached: result.service?.cached ?? false,
        },
        filename,
        size: result.file.size ?? original.size,
        folderSize: result.size ?? original.folderSize,
        nzbUrl: result.nzb,
      });
    }
  }

  return {
    streams: [...resolvedStreams, ...streams],
    errors,
    hasNewStreams: resolvedStreams.length > 0,
  };
}

/**
 * Resolves service-wrapped P2P streams through configured debrid services.
 *
 * When "Service Wrap" is enabled, external addons are configured to return raw P2P
 * torrent results instead of debrid results. This function processes those raw torrents
 * through the user's configured debrid services.
 *
 * When "Reconfigure Service" is also enabled, existing debrid results from the
 * selected addons that include an infoHash are re-processed through the configured
 * debrid services. This allows resolving those torrents through different/additional
 * services that the original addon may not support.
 */
export async function resolveServiceWrappedStreams(
  streams: ParsedStream[],
  context: StreamContext,
  userData: UserData,
  addons: Addon[]
): Promise<ServiceWrapResult> {
  if (!userData.serviceWrap?.enabled) {
    return { streams, errors: [], hasNewStreams: false };
  }

  const errors: ServiceWrapError[] = [];

  // Identify serviceWrapped addon instanceIds
  const serviceWrappedInstanceIds = new Set<string>();
  for (const addon of addons) {
    if (addon.serviceWrapped) {
      serviceWrappedInstanceIds.add(addon.instanceId!);
    }
  }

  // Build set of preset instanceIds that are in scope for service wrap
  const serviceWrapPresets = userData.serviceWrap.presets;
  const isPresetInScope = (presetId: string) =>
    !serviceWrapPresets ||
    serviceWrapPresets.length === 0 ||
    serviceWrapPresets.includes(presetId);

  const reconfigureEnabled = userData.serviceWrap.reconfigureService;

  const wrappedP2PStreams: ParsedStream[] = [];
  const reconfigureStreams: ParsedStream[] = [];
  const otherStreams: ParsedStream[] = [];

  const presetList = PresetManager.getPresetList();

  for (const stream of streams) {
    const isWrapped = stream.addon.instanceId
      ? serviceWrappedInstanceIds.has(stream.addon.instanceId)
      : false;

    const presetMeta = presetList.find((p) => p.ID === stream.addon.preset.id);

    const presetInScope = isPresetInScope(stream.addon.preset.id);

    if (isWrapped && stream.type === 'p2p') {
      // Explicitly service-wrapped addon (generated by applyPresets)
      wrappedP2PStreams.push(stream);
    } else if (
      !isWrapped &&
      stream.type === 'p2p' &&
      stream.torrent?.infoHash &&
      presetInScope
    ) {
      // Non-serviceWrapped addon (e.g. custom addon) returning P2P results
      // that should be service-wrapped when preset is in scope
      wrappedP2PStreams.push(stream);
    } else if (
      reconfigureEnabled &&
      !presetMeta?.BUILTIN &&
      !isWrapped &&
      stream.type === 'debrid' &&
      stream.torrent?.infoHash &&
      presetInScope
    ) {
      // Reconfigure: debrid stream from an in-scope addon with infoHash available.
      // Keep it in otherStreams too (original debrid result stays), but also
      // add the hash to our pipeline for re-processing through additional services.
      reconfigureStreams.push(stream);
      otherStreams.push(stream);
    } else {
      otherStreams.push(stream);
    }
  }

  if (wrappedP2PStreams.length === 0 && reconfigureStreams.length === 0) {
    return { streams, errors, hasNewStreams: false };
  }

  if (reconfigureStreams.length > 0) {
    logger.debug(
      { count: reconfigureStreams.length },
      'reconfigure service: found debrid streams with infohash'
    );
  }

  logger.debug(
    {
      wrapped: wrappedP2PStreams.length,
      reconfigure: reconfigureStreams.length,
    },
    'resolving streams through debrid services'
  );

  // Build BuiltinDebridServices from user's service configuration
  const debridServices = buildDebridServices(userData);

  if (debridServices.length === 0) {
    errors.push({
      title: '❌ No debrid services',
      description:
        'No debrid services are configured to process service-wrapped addon results.',
    });
    return { streams: otherStreams, errors, hasNewStreams: false };
  }

  // Split services into torrent-capable only (exclude usenet-only services)
  const torrentServices = debridServices.filter(
    (s) => !['nzbdav', 'altmount'].includes(s.id)
  );

  // Reconstruct Torrent[] from wrapped external P2P AND reconfigure streams
  const allTorrentSourceStreams = [...wrappedP2PStreams, ...reconfigureStreams];
  const uniqueTorrents = buildAndDeduplicateTorrents(allTorrentSourceStreams);

  if (uniqueTorrents.length === 0 || torrentServices.length === 0) {
    if (torrentServices.length === 0 && wrappedP2PStreams.length > 0) {
      errors.push({
        title: '❌ No Torrent Services',
        description:
          'No torrent debrid services configured to process service-wrapped P2P torrent results.',
      });
    }
    return { streams: otherStreams, errors, hasNewStreams: false };
  }

  // Build metadata from StreamContext
  const metadata = await buildMetadata(context);

  // Process torrents through debrid services
  const processedTorrents = await processTorrents(
    uniqueTorrents,
    torrentServices,
    context.id,
    metadata,
    userData.ip,
    userData.checkOwned
  );

  // Collect debrid processing errors
  for (const error of processedTorrents.errors) {
    errors.push({
      title: `[❌] Service Wrap`,
      description: `[${constants.SERVICE_DETAILS[error.serviceId].shortName}] ${error.error.message}`,
    });
  }

  const serviceTimings = processedTorrents.serviceTimings;

  if (processedTorrents.results.length === 0) {
    return {
      streams: otherStreams,
      errors,
      hasNewStreams: false,
      serviceTimings,
    };
  }

  // Build encrypted store auths for each service
  const encryptedStoreAuths = buildEncryptedStoreAuths(debridServices);

  const metadataToStore = metadata || { titles: [] };
  const metadataId = getSimpleTextHash(JSON.stringify(metadataToStore));
  await metadataStore().set(
    metadataId,
    metadataToStore,
    appConfig.builtins.debrid.playbackLinkValidity,
    true
  );

  // Map original ParsedStreams by infoHash for result attribution
  const p2pByHash = new Map<string, ParsedStream[]>();
  for (const stream of allTorrentSourceStreams) {
    const hash = stream.torrent?.infoHash;
    if (hash) {
      const existing = p2pByHash.get(hash) ?? [];
      existing.push(stream);
      p2pByHash.set(hash, existing);
    }
  }

  const debridStreams = await buildDebridStreams(
    processedTorrents.results,
    p2pByHash,
    encryptedStoreAuths,
    metadataId,
    userData,
    addons,
    metadata
  );

  logger.debug(
    {
      debrid: debridStreams.length,
      wrapped: wrappedP2PStreams.length,
      reconfigure: reconfigureStreams.length,
    },
    'resolved debrid streams'
  );

  return {
    streams: [...debridStreams, ...otherStreams],
    errors,
    hasNewStreams: debridStreams.length > 0,
    serviceTimings,
  };
}

// ---------------------------------------------------------------------------
// Helper functions
// ---------------------------------------------------------------------------

function buildDebridServices(userData: UserData): BuiltinDebridServices {
  const enabledServices =
    userData.services?.filter((s) => s.enabled !== false) ?? [];
  const serviceWrapFilter = userData.serviceWrap?.services;
  const builtinServiceIds = new Set(constants.BUILTIN_SUPPORTED_SERVICES);
  const debridServices: BuiltinDebridServices = [];

  for (const service of enabledServices) {
    if (!builtinServiceIds.has(service.id as BuiltinServiceId)) continue;
    if (
      serviceWrapFilter &&
      serviceWrapFilter.length > 0 &&
      !serviceWrapFilter.includes(service.id as any)
    )
      continue;
    try {
      const credential = getServiceCredential(service);
      if (credential) {
        debridServices.push({
          id: service.id as BuiltinServiceId,
          credential:
            typeof credential === 'string'
              ? credential
              : JSON.stringify(credential),
        });
      }
    } catch (error) {
      logger.warn(
        {
          serviceId: service.id,
          err:
            error instanceof Error ? (error as Error).message : String(error),
        },
        'failed to get credential for service'
      );
    }
  }

  return debridServices;
}

function buildAndDeduplicateTorrents(streams: ParsedStream[]): Torrent[] {
  const torrents: Torrent[] = streams
    .filter((s) => s.torrent?.infoHash)
    .map((s) => ({
      type: 'torrent' as const,
      hash: s.torrent!.infoHash!,
      title: s.folderName ?? s.filename ?? '',
      size: s.folderSize ?? s.size ?? 0,
      sources: s.torrent?.sources ?? [],
      indexer: s.indexer,
      seeders: s.torrent?.seeders,
      age: s.age,
      private: s.torrent?.private,
      group: s.parsedFile?.releaseGroup,
      confirmed: true,
      duration: s.duration,
    }));

  const seenHashes = new Set<string>();
  const uniqueTorrents: Torrent[] = [];
  for (const torrent of torrents) {
    if (!seenHashes.has(torrent.hash)) {
      seenHashes.add(torrent.hash);
      uniqueTorrents.push(torrent);
    }
  }

  logger.debug(
    { from: torrents.length, to: uniqueTorrents.length },
    'deduplicated torrents'
  );

  return uniqueTorrents;
}

async function buildMetadata(
  context: StreamContext
): Promise<TitleMetadata | undefined> {
  const contextMetadata = await context.getMetadata();
  if (!contextMetadata) return undefined;

  return {
    titles: contextMetadata.titles?.map((t) => t.title) ?? [
      contextMetadata.title,
    ],
    season: context.parsedId?.season
      ? Number(context.parsedId.season)
      : undefined,
    episode: context.parsedId?.episode
      ? Number(context.parsedId.episode)
      : undefined,
    absoluteEpisode: contextMetadata.absoluteEpisode,
    relativeAbsoluteEpisode: contextMetadata.relativeAbsoluteEpisode,
    seasonYear: contextMetadata.seasonYear,
  };
}

function buildEncryptedStoreAuths(
  debridServices: BuiltinDebridServices
): Record<BuiltinServiceId, string | string[]> {
  return debridServices.reduce(
    (acc, service) => {
      const auth = { id: service.id, credential: service.credential };
      acc[service.id] = encryptString(JSON.stringify(auth)).data ?? '';
      return acc;
    },
    {} as Record<BuiltinServiceId, string | string[]>
  );
}

async function buildDebridStreams(
  results: Awaited<ReturnType<typeof processTorrents>>['results'],
  p2pByHash: Map<string, ParsedStream[]>,
  encryptedStoreAuths: Record<BuiltinServiceId, string | string[]>,
  metadataId: string,
  userData: UserData,
  addons: Addon[],
  metadata: TitleMetadata | undefined
): Promise<ParsedStream[]> {
  const debridStreams: ParsedStream[] = [];

  const normaliseText = (text: string) => {
    return text
      .replace(
        /(mkv|mp4|avi|mov|wmv|flv|webm|m4v|mpg|mpeg|3gp|3g2|m2ts|ts|vob|ogv|ogm|divx|xvid|rm|rmvb|asf|mxf|mka|mks|mk3d|webm|f4v|f4p|f4a|f4b)$/i,
        ''
      )
      .replace(/[^\p{L}\p{N}+]/gu, '')
      .toLowerCase()
      .trim();
  };

  for (const result of results) {
    const encryptedStoreAuth = result.service
      ? encryptedStoreAuths[result.service.id]
      : undefined;

    // Find ALL original ParsedStreams this result came from (by infoHash).
    const originals = p2pByHash.get(result.hash) ?? [];
    const isPrivate = result.private;

    // If no originals found (shouldn't happen), create a minimal fallback
    const streamsToProcess = originals.length > 0 ? originals : [undefined];

    for (const original of streamsToProcess) {
      const fileInfo: FileInfo | undefined = result.service
        ? {
            type: 'torrent',
            downloadUrl: result.downloadUrl,
            title: result.title,
            hash: result.hash,
            private: result.private,
            sources: result.sources,
            index: result.file.index,
            fileIndex: metadata ? undefined : original?.torrent?.fileIdx,
            cacheAndPlay:
              userData.cacheAndPlay?.enabled &&
              userData.cacheAndPlay?.streamTypes?.includes('torrent'),
            autoRemoveDownloads: userData.autoRemoveDownloads,
            torbox:
              result.service.id === 'torbox'
                ? getTorboxRouteConfig(userData)
                : undefined,
          }
        : undefined;

      // Generate playback URL
      let url: string | undefined;
      if (
        result.service &&
        result.service.id !== 'stremio_nntp' &&
        encryptedStoreAuth &&
        fileInfo
      ) {
        url = generatePlaybackUrl(
          encryptedStoreAuth as string,
          metadataId,
          fileInfo,
          result.file.name ?? result.title
        );
      }
      const debridStream: ParsedStream = {
        ...(original ?? {
          id: `wrap-${result.hash}-${result.service?.id}`,
          addon: addons[0] ?? {
            preset: { id: 'unknown', type: 'unknown', options: {} },
            manifestUrl: '',
            enabled: true,
            name: 'Service Wrap',
            timeout: 30,
          },
        }),
        id: `${original?.id ?? 'wrap'}-${result.service?.id}`,
        type: 'debrid',
        url,
        service: result.service
          ? {
              id: result.service.id,
              cached: result.service.cached,
            }
          : undefined,
        library: result.service?.library,
        size: result.file.size,
        folderSize: result.size,
        filename: result.file.name ?? result.title ?? original?.filename,
        folderName: result.file.name ? result.title : original?.folderName,
        torrent: {
          infoHash: result.hash,
          fileIdx: original?.torrent?.fileIdx ?? result.file.index,
          seeders: 'seeders' in result ? result.seeders : undefined,
          sources: result.sources,
          private: isPrivate,
        },
      };

      const parsedMediaInfo = mergeParsedMediaInfos(
        original?.parsedFile,
        result.parsedMediaInfo
      );
      if (result.parsedMediaInfo && parsedMediaInfo) {
        debridStream.parsedFile = {
          ...debridStream.parsedFile,
          ...parsedMediaInfo,
          languages: parsedMediaInfo.languages?.length
            ? parsedMediaInfo.languages
            : (debridStream.parsedFile?.languages ?? []),
          subtitles: parsedMediaInfo.subtitles?.length
            ? parsedMediaInfo.subtitles
            : (debridStream.parsedFile?.subtitles ?? []),
          audioChannels: parsedMediaInfo.audioChannels?.length
            ? parsedMediaInfo.audioChannels
            : (debridStream.parsedFile?.audioChannels ?? []),
          visualTags: parsedMediaInfo.visualTags?.length
            ? parsedMediaInfo.visualTags
            : (debridStream.parsedFile?.visualTags ?? []),
          audioTags: parsedMediaInfo.audioTags?.length
            ? parsedMediaInfo.audioTags
            : (debridStream.parsedFile?.audioTags ?? []),
          hasChapters:
            parsedMediaInfo.hasChapters ?? debridStream.parsedFile?.hasChapters,
        };
        debridStream.duration =
          parsedMediaInfo.duration != null
            ? parsedMediaInfo.duration * 1000
            : debridStream.duration;
        debridStream.bitrate = parsedMediaInfo.bitrate ?? debridStream.bitrate;
      }

      // if folder size within 5% of file size, remove folder size to avoid redundant information.
      if (
        debridStream.folderSize &&
        debridStream.size &&
        Math.abs(
          (debridStream.folderSize - debridStream.size) / debridStream.size
        ) <= 0.05
      ) {
        debridStream.folderSize = undefined;
      }

      if (
        debridStream.folderName &&
        debridStream.filename &&
        normaliseText(debridStream.folderName) ===
          normaliseText(debridStream.filename)
      ) {
        debridStream.folderName = undefined;
      }

      // if original didnt have a foldername, but debrid result does and its filename is different from the original, re-parse both filename and foldername.
      if (
        original &&
        debridStream.filename &&
        original.filename &&
        debridStream.filename !== original.filename &&
        !original.folderName &&
        debridStream.folderName &&
        debridStream.parsedFile
      ) {
        // Re-parse the new filename and folder name to extract title/season/episode info
        const fileParsed = parseTorrentTitleCached(debridStream.filename);
        const folderParsed = parseTorrentTitleCached(debridStream.folderName);

        const seasons = fileParsed.seasons?.length
          ? fileParsed.seasons
          : folderParsed.seasons;
        const episodes = fileParsed.episodes?.length
          ? fileParsed.episodes
          : folderParsed.episodes;
        const seasonPack =
          !!(fileParsed.seasons?.length && !fileParsed.episodes?.length) ||
          !!(folderParsed.seasons?.length && !folderParsed.episodes?.length);

        debridStream.parsedFile = {
          ...debridStream.parsedFile,
          title: folderParsed.title || fileParsed.title,
          seasons,
          episodes,
          folderSeasons:
            seasons !== folderParsed.seasons ? folderParsed.seasons : undefined,
          folderEpisodes:
            episodes !== folderParsed.episodes
              ? folderParsed.episodes
              : undefined,
          seasonPack,
        };

        // force re-calculation of bitrate if it was estimated before.
        if (!debridStream.duration && debridStream.bitrate)
          debridStream.bitrate = undefined;

        // Apply the same season pack heuristics as StreamParser.getParsedFile
        if (
          !debridStream.parsedFile.seasonPack &&
          debridStream.parsedFile.episodes &&
          debridStream.parsedFile.episodes.length > 0 &&
          debridStream.folderSize &&
          debridStream.size &&
          debridStream.folderSize > debridStream.size * 2
        ) {
          debridStream.parsedFile.seasonPack = true;
        }
        if (
          !debridStream.parsedFile.seasonPack &&
          debridStream.parsedFile.episodes &&
          debridStream.parsedFile.episodes.length > 5
        ) {
          debridStream.parsedFile.seasonPack = true;
        }
      }

      debridStreams.push(debridStream);
    }
  }

  await fileInfoStore()?.flush();

  return debridStreams;
}

/**
 * Extracts the appropriate credential string for a given service
 * from the user's service configuration.
 */
export function getServiceCredential(service: {
  id: string;
  credentials?: Record<string, string>;
}): string | undefined {
  const creds = service.credentials;
  if (!creds) return undefined;

  // Only need to handle torrent-based services.
  switch (service.id) {
    case constants.SEEDR_SERVICE:
      return creds.encodedToken;
    case constants.PIKPAK_SERVICE:
      return JSON.stringify({
        email: creds.email,
        password: creds.password,
      });
    default:
      return creds.apiKey;
  }
}
